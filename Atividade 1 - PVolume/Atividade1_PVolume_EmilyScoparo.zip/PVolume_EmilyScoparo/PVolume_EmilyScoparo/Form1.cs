﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume_EmilyScoparo
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((double.TryParse(txtRaio.Text, out altura)) && (double.TryParse(txtRaio.Text, out raio)))
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
            else
                MessageBox.Show("Dados invalidos!");
        }
    }
}
