﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Globalization;


namespace P0030482023045
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[10, 4];
            string aux = "";
            double totalMensal = 0, totalSemana = 0, totalGeral = 0;

            for (var i = 0; i < 10; i++)
            {
                totalMensal = 0;
                for (var j = 0; j < 4; j++)
                {
                    aux = Interaction.InputBox("Total do mês: " + (i + 1).ToString() + " Semana: " + (j + 1).ToString(),
                        "Entrada de dados"); 

                    if (double.TryParse(aux, out vendas[i, j]) &&
                        (vendas[i, j] >= 0))
                    {
                        totalSemana = vendas[i, j];
                        lboxTotal.Items.Add("Total do Mês: " + (i + 1) + " Semana: " + (j + 1) + " " +
                            totalSemana.ToString("C2", CultureInfo.CurrentCulture));

                    }
                    else
                    {
                        MessageBox.Show("Valor inválido!    !");
                        j--;
                    }
                    totalMensal += totalSemana;
                }
                totalGeral += totalMensal;

                lboxTotal.Items.Add("Total Mês = " + totalMensal.ToString("C2", CultureInfo.CurrentCulture));
                lboxTotal.Items.Add("............................");

            }
            lboxTotal.Items.Add("Total Geral = " + totalGeral.ToString("C2", CultureInfo.CurrentCulture));
        }
    }
}
