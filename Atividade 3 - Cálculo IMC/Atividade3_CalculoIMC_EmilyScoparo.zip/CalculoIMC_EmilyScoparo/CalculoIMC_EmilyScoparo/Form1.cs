﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculoIMC_EmilyScoparo
{
    public partial class FormCalculoIMC : Form
    {
        double pesoAtual, altura, IMC;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPesoAtual.Text = "";
            mskbxAltura.Text = "";
            mskbxIMC.Text = "";
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        public FormCalculoIMC()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            pesoAtual = double.Parse(mskbxPesoAtual.Text);
            altura = double.Parse(mskbxAltura.Text);
            IMC = Math.Round(pesoAtual/ (Math.Pow(altura, 2)), 2);
            mskbxIMC.Text = IMC.ToString();

            if (IMC < 18.5)
            {
                MessageBox.Show("Voce esta abaixo do peso. Faça uma dieta para engordar!");
            }
            else if (IMC >= 18.5 && IMC < 24.9)
            {
                MessageBox.Show("Voce tem o peso ideal!");
            }
            else if (IMC >= 25 && IMC < 29.9)
            {
                MessageBox.Show("Voce esta com sobrepeso. Tente emagrecer um pouco!");
            }
            else if (IMC >= 30 && IMC < 34.9)
            {
                MessageBox.Show("Voce esta com obesidade grau I. Faça uma dieta para emagrecer!");
            }
            else if (IMC >= 35 && IMC < 39.9)
            {
                MessageBox.Show("Voce esta com obesidade grau II. Faça uma dieta para emagrecer!");
            }
            else if (IMC >= 40)
            {
                MessageBox.Show("Voce esta com obesidade grau III (morbida). Procure um medico e faça uma dieta para emagrecer!");
            }
        }
    }
}
