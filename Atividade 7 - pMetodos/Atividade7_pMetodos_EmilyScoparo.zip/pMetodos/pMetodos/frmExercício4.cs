﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMetodos
{
    public partial class frmExercício4 : Form
    {
        public frmExercício4()
        {
            InitializeComponent();
        }

        private void btnQntNumericos_Click(object sender, EventArgs e)
        {
            int qntNumericos = 0, i;

            for(i=0; i<richtxtboxTexto.Text.Length; i++)
            {
                if(char.IsNumber(richtxtboxTexto.Text[i]))
                {
                    qntNumericos++;
                }
            }
         
            MessageBox.Show("Quantidade de caracteres numéricos: " + qntNumericos);
        }

        private void btnPosicaoEspaco_Click(object sender, EventArgs e)
        {
            int i = 0, primeiroEspaco = 0;

            while(i<richtxtboxTexto.Text.Length)
            {
                if(char.IsWhiteSpace(richtxtboxTexto.Text[i]))
                {
                    primeiroEspaco = i;
                }

                i++;
            }

            MessageBox.Show("A POSIÇÃO DO PRIMEIRO ESPAÇO É: " + primeiroEspaco);
        }

        private void btnQntAlfabeticos_Click(object sender, EventArgs e)
        {
            int qntAlfabeticos=0;

            foreach(char x in richtxtboxTexto.Text)
            {
                if(char.IsLetter(x))
                {
                    qntAlfabeticos++;
                }
            }

            MessageBox.Show("QUANTIDADE DE CARACTERES ALFABETICOS: " + qntAlfabeticos);

        }
    }
}
