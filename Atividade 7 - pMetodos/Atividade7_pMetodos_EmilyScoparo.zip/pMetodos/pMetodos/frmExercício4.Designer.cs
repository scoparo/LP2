﻿
namespace pMetodos
{
    partial class frmExercício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richtxtboxTexto = new System.Windows.Forms.RichTextBox();
            this.btnQntNumericos = new System.Windows.Forms.Button();
            this.btnPosicaoEspaco = new System.Windows.Forms.Button();
            this.btnQntAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richtxtboxTexto
            // 
            this.richtxtboxTexto.Location = new System.Drawing.Point(216, 62);
            this.richtxtboxTexto.Name = "richtxtboxTexto";
            this.richtxtboxTexto.Size = new System.Drawing.Size(397, 164);
            this.richtxtboxTexto.TabIndex = 0;
            this.richtxtboxTexto.Text = "";
            // 
            // btnQntNumericos
            // 
            this.btnQntNumericos.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnQntNumericos.Location = new System.Drawing.Point(122, 266);
            this.btnQntNumericos.Name = "btnQntNumericos";
            this.btnQntNumericos.Size = new System.Drawing.Size(166, 113);
            this.btnQntNumericos.TabIndex = 1;
            this.btnQntNumericos.Text = "CALCULAR QUANTIDADE DE CARACTERES NUMÉRICOS";
            this.btnQntNumericos.UseVisualStyleBackColor = true;
            this.btnQntNumericos.Click += new System.EventHandler(this.btnQntNumericos_Click);
            // 
            // btnPosicaoEspaco
            // 
            this.btnPosicaoEspaco.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPosicaoEspaco.Location = new System.Drawing.Point(331, 266);
            this.btnPosicaoEspaco.Name = "btnPosicaoEspaco";
            this.btnPosicaoEspaco.Size = new System.Drawing.Size(166, 113);
            this.btnPosicaoEspaco.TabIndex = 2;
            this.btnPosicaoEspaco.Text = "POSIÇÃO DO PRIMEIRO ESPAÇO";
            this.btnPosicaoEspaco.UseVisualStyleBackColor = true;
            this.btnPosicaoEspaco.Click += new System.EventHandler(this.btnPosicaoEspaco_Click);
            // 
            // btnQntAlfabeticos
            // 
            this.btnQntAlfabeticos.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnQntAlfabeticos.Location = new System.Drawing.Point(541, 266);
            this.btnQntAlfabeticos.Name = "btnQntAlfabeticos";
            this.btnQntAlfabeticos.Size = new System.Drawing.Size(166, 113);
            this.btnQntAlfabeticos.TabIndex = 3;
            this.btnQntAlfabeticos.Text = "CALCULAR QUANTIDADE DE CARACTERES ALFABÉTICOS";
            this.btnQntAlfabeticos.UseVisualStyleBackColor = true;
            this.btnQntAlfabeticos.Click += new System.EventHandler(this.btnQntAlfabeticos_Click);
            // 
            // frmExercício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 400);
            this.Controls.Add(this.btnQntAlfabeticos);
            this.Controls.Add(this.btnPosicaoEspaco);
            this.Controls.Add(this.btnQntNumericos);
            this.Controls.Add(this.richtxtboxTexto);
            this.Name = "frmExercício4";
            this.Text = "frmExercício4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richtxtboxTexto;
        private System.Windows.Forms.Button btnQntNumericos;
        private System.Windows.Forms.Button btnPosicaoEspaco;
        private System.Windows.Forms.Button btnQntAlfabeticos;
    }
}