﻿
namespace pMetodos
{
    partial class frmExercício4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.c = new System.Windows.Forms.RichTextBox();
            this.btnQntNumericos = new System.Windows.Forms.Button();
            this.btnPosicaoEspaco = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // c
            // 
            this.c.Location = new System.Drawing.Point(216, 62);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(397, 164);
            this.c.TabIndex = 0;
            this.c.Text = "";
            // 
            // btnQntNumericos
            // 
            this.btnQntNumericos.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnQntNumericos.Location = new System.Drawing.Point(122, 266);
            this.btnQntNumericos.Name = "btnQntNumericos";
            this.btnQntNumericos.Size = new System.Drawing.Size(166, 113);
            this.btnQntNumericos.TabIndex = 1;
            this.btnQntNumericos.Text = "CALCULAR QUANTIDADE DE CARACTERES NUMÉRICOS";
            this.btnQntNumericos.UseVisualStyleBackColor = true;
            this.btnQntNumericos.Click += new System.EventHandler(this.btnQntNumericos_Click);
            // 
            // btnPosicaoEspaco
            // 
            this.btnPosicaoEspaco.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPosicaoEspaco.Location = new System.Drawing.Point(331, 266);
            this.btnPosicaoEspaco.Name = "btnPosicaoEspaco";
            this.btnPosicaoEspaco.Size = new System.Drawing.Size(166, 113);
            this.btnPosicaoEspaco.TabIndex = 2;
            this.btnPosicaoEspaco.Text = "POSIÇÃO DO PRIMEIRO ESPAÇO";
            this.btnPosicaoEspaco.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button3.Location = new System.Drawing.Point(541, 266);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(166, 113);
            this.button3.TabIndex = 3;
            this.button3.Text = "CALCULAR QUANTIDADE DE CARACTERES ALFABÉTICOS";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // frmExercício4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 400);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnPosicaoEspaco);
            this.Controls.Add(this.btnQntNumericos);
            this.Controls.Add(this.c);
            this.Name = "frmExercício4";
            this.Text = "frmExercício4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox c;
        private System.Windows.Forms.Button btnQntNumericos;
        private System.Windows.Forms.Button btnPosicaoEspaco;
        private System.Windows.Forms.Button button3;
    }
}