﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMetodos
{
    public partial class frmExercício5 : Form
    {
        public frmExercício5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        { 
            if (Convert.ToInt32(txtNumero1.Text) <= Convert.ToInt32(txtNumero2.Text))
            {
                Random random = new Random();
                double r = random.Next(Convert.ToInt32(txtNumero1.Text), Convert.ToInt32(txtNumero2.Text));
                MessageBox.Show(r.ToString());
            }
            else
            {
                MessageBox.Show("Números inválidos");
            }
        }
    }
}
