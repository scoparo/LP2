﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_EmilyScoparo
{
    public partial class Form1 : Form
    {
        double Num1, Num2, Resultado;

        private void btnMenos_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Num1) && double.TryParse(txtNum2.Text, out Num2))
            {
                Resultado = Num1 - Num2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Numeros invalidos");
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Num1) && double.TryParse(txtNum2.Text, out Num2))
            {
                Resultado = Num1 / Num2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Numeros invalidos");
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Num1) && double.TryParse(txtNum2.Text, out Num2))
            {
                Resultado = Num1 * Num2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Numeros invalidos");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtResultado.Text = "";

            txtNum1.Focus();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtNum1.Text, out Num1) && double.TryParse(txtNum2.Text, out Num2))
            {
                Resultado = Num1 + Num2;
                txtResultado.Text = Resultado.ToString();
            }
            else
                MessageBox.Show("Numeros invalidos");
        }
    }
}
