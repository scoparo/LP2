﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo_EmilyScoparo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtLadoA.Text, out ladoA) && double.TryParse(txtLadoB.Text, out ladoB) && double.TryParse(txtLadoC.Text, out ladoC))
            {
                if (ladoA > 0 && ladoB > 0 && ladoC > 0)
                {
                    if (Math.Abs(ladoB - ladoC) < ladoA && ladoA < (ladoB + ladoC) && Math.Abs(ladoA - ladoB) < ladoC && ladoC < (ladoA + ladoB) && Math.Abs(ladoA - ladoC) < ladoB && ladoB < (ladoA + ladoC))
                    {
                        if (ladoA == ladoB && ladoB == ladoC)
                            MessageBox.Show("Triangulo equilatero");

                        else if (ladoA != ladoB && ladoB != ladoC && ladoC != ladoA)
                            MessageBox.Show("Triangulo escaleno");
                        
                        else
                            MessageBox.Show("Triangulo isoceles");
                    }
                    
                    else
                    {
                        MessageBox.Show("Nao entra na regra dos triangulos");
                    }
                }

                else
                {
                    MessageBox.Show("Nao pode ser igual ou menor que 0");
                }
            }

            else
            {
                MessageBox.Show("Dados incorretos");
            }
        }
    }
}
